let creditTotal = 700;
function credit(elementID, resultID) {
let val = document.getElementById(elementID).value;
let resultElement = document.getElementById(resultID);
 val = parseInt(val);
creditTotal -= val;
switch (true) {
case creditTotal > 0:
resultElement.textContent = 'задолженнось: ' + creditTotal;
break;
case creditTotal < 0:
resultElement.textContent = 'переплата: ' + (creditTotal + -0);
break;
case creditTotal === 0:
resultElement.textContent = 'задолности нет';
}
}